"""

2.
NUMBER ANALYSIS SYSTEM

Scenario:

A software company wants to develop a Number Analysis System. The application should be menu-driven and perform different mathematical operations on a given number.

MENU

1. Check Perfect Number
2. Check Prime Number
3. Find Reverse of a Number
4. Calculate Factorial
5. Display Factors of a Number
6. Exit

Requirements

Choice 1 – Check Perfect Number

* Accept a number from the user.
* Pass the number to a function.
* The function should return True if the number is Perfect, otherwise False.
* Display an appropriate message based on the returned value.

Choice 2 – Check Prime Number

* Accept a number from the user.
* Pass the number to a function.
* The function should return a message such as "Prime Number" or "Not a Prime Number".
* Display the returned message.

Choice 3 – Find Reverse of a Number

* Accept a number from the user.
* Pass the number to a function.
* The function should return the reversed number.
* Display the returned value.

Choice 4 – Calculate Factorial

* Accept a number from the user.
* Pass the number to a function.
* The function should return the factorial value.
* Display the returned value.

Choice 5 – Display Factors of a Number

* Accept a number from the user.
* Pass the number to a function.
* The function should return all factors of the given number.
* Display the returned factors.

Choice 6 – Exit

Sample Output

Enter Choice : 1

Enter Number : 28

28 is a Perfect Number

---

Enter Choice : 2

Enter Number : 17

Prime Number

---

Enter Choice : 3

Enter Number : 1234

Reverse Number : 4321

---

Enter Choice : 4

Enter Number : 5

Factorial : 120

---

Enter Choice : 5

Enter Number : 12

Factors : 1 2 3 4 6 12

---

Important Instructions

1. Create separate functions for each operation.
2. Use parameters to pass values to functions.
3. Use return statements appropriately.
4. Different functions should return different types of values such as Boolean, String, Integer, and Collection/List.
5. Avoid using global variables.
6. Implement the solution using a menu-driven approach.
7. Write meaningful function names and maintain proper code readability.

"""

def perfect():
     sum=0
     n=int(input("Enter number :"))
     for i in range(1,n//2+1):
         if n%i==0:
               sum+=i
     if sum==n:
         print("Perfect Number")
     else:
         print("Non Perfect Number")

def prime():
     count=0
     n=int(input("Enter number :"))
     if n==1:
         print("Non prime ")
     else:
         for i in range(1,n//2+1):
             if n%i==0:
                 count+=1
             if count==2:
                print("Non prime")
                break
         else:
             print("Prime") 
        
def reverse():
       rev=0
       n=int(input("Enter Number :"))
       while n:
          x=n%10
          n=n//10
          rev=rev*10+x
       print("Reverse :",rev)

def factorial():
       x=1
       n=int(input("Enter number :"))
       while n:
          x*=n
          n-=1
       print("Factorial :",x)

def factors():
       n=int(input("Enter number :"))
       for i in range(1,n):
           if  n%i==0:
               print(i,end=" ")
          

while True:
     print()
     print("""MENU

1. Check Perfect Number
2. Check Prime Number
3. Find Reverse of a Number
4. Calculate Factorial
5. Display Factors of a Number
6. Exit""")
     c=int(input("Enter choice :"))
     match(c):
         case 1:
               perfect()
         case 2:
               prime()
         case 3:
               reverse()
         case 4:
              factorial()
         case 5:
              factors()
         case 6:
               break